# Phase 15 Evidence

Date started: 2026-06-01

## Current Status

Phase 15 is complete locally as of 2026-06-01. The first slice adds schema support for OCR-derived
text and password-protected PDFs:

- `Books.IsOcrDerived` and `Books.IsPasswordProtected` with default `false`.
- `ExtractedPages.Source` with default `"Extraction"` and source-aware unique
  indexing for `(BookId, Source, PageNumber)`.
- `ExtractedTextStore` preserves the existing extraction default while allowing
  OCR and native-extraction rows for the same book/page.
- EF Core migration `20260601160606_Phase15OcrPowerReaderSchema` includes an
  explicit `Down()` path.
The first WP2 reliability slice is also in place: `IOcrProvider`,
`OcrJobPayload`, and `OcrJobProcessor` process pending/interrupted OCR jobs,
persist OCR text as `ExtractedPages.Source = "OCR"`, mark books as OCR-derived,
replace page search chunks so scanned books become searchable, and enqueue
follow-up FTS and embedding handoff jobs. The native Tesseract provider and
hosted `OcrWorker` are registered through the composition root without loading
native OCR binaries until a queued OCR job actually runs. English language data
is supplied through `Tesseract.Data.English`, which copies
`tessdata/eng.traineddata` to the app output.
The WP4 reader handoff now opens protected PDFs through `OpenProtectedAsync`,
passes the password to the PDFium adapter, clears provider-owned password
buffers after open, and covers the known-password PDF render path.
WP4 now has platform coverage for the password provider boundary: Windows uses
Credential Manager, macOS resolves stored credentials through Keychain's
`security` tool, non-supported platforms fail closed, and the book-detail panel
can forget a stored OS credential without changing the protected-book catalogue
flag.
The first WP6 scale-hardening slice adds provider-specific rate limiting and
429/503 retry handling to the Google Books and Open Library HTTP clients.
Batch enrichment jobs are now tagged with recoverable 50-book chunk metadata
while preserving the existing per-book job isolation and older file-path payloads.
The health service now summarizes batch enrichment runs, pauses pending/running
jobs by batch id, resumes paused/failed jobs, and exports failed jobs as CSV for
operator review. A 2,000-book simulation verifies chunking, retry recovery, and
completion within the local performance gate.
WP7 smart-shelf scale work is in place: the catalogue migration adds composite
indexes for status/year, shelf membership, and metadata field/value filters; the
2,000-book benchmark verifies five common query shapes under the 2,000 ms P95
budget and records their SQLite query plans.
WP8 is now guarded by the Phase 13 extension pattern: `IOcrProvider` is marked
`[ExtensionPoint]`, kept internal through friend assemblies, and covered by an
architecture visibility test.
WP3 OCR job controls are wired through the Index Manager: queued/running OCR jobs
can be paused or cancelled, failed/paused/cancelled jobs can be retried, and the
panel exposes localized action labels for each job row.
WP3 now also has the book-detail OCR trigger: the detail panel can queue a scanned
book for OCR, shows localized queued/already-queued/error status, and the queue
service rejects duplicate jobs, missing files, and path traversal outside the
configured library root.
WP7 is complete locally: the Index Manager now exposes Smart Shelf Query Stats
with the latest measured query time and health for the three Phase 15 composite
indexes.

## Verified Locally

| Gate | Evidence |
| --- | --- |
| `dotnet test tests\OgmaLibrary.Tests\OgmaLibrary.Tests.csproj --configuration Release --no-restore --filter FullyQualifiedName~Phase15OcrSchemaTests` | Passed: 3 schema/source/migration tests |
| `dotnet test tests\OgmaLibrary.Tests\OgmaLibrary.Tests.csproj --configuration Release --no-restore --filter FullyQualifiedName~OcrJobProcessorTests` | Passed: 2 OCR processor reliability tests |
| `dotnet test tests\OgmaLibrary.Tests\OgmaLibrary.Tests.csproj --configuration Release --no-restore --filter FullyQualifiedName~OcrWorkerTests` | Passed: 1 hosted worker scheduling test |
| `dotnet test tests\OgmaLibrary.Tests\OgmaLibrary.Tests.csproj --configuration Release --no-restore --filter FullyQualifiedName~IndexManagerServiceTests` | Passed: 4 index-manager backend tests including OCR job status projection |
| `dotnet test tests\OgmaLibrary.Tests.Ui\OgmaLibrary.Tests.Ui.csproj --configuration Release --no-restore --filter FullyQualifiedName~SearchViewModelTests` | Passed: 8 UI/view-model tests including localized OCR job progress |
| `dotnet test tests\OgmaLibrary.Tests.Ui\OgmaLibrary.Tests.Ui.csproj --configuration Release --no-restore --filter FullyQualifiedName~ShellReaderNavigationTests` | Passed: 4 shell route tests including split-view V2 scaffold |
| `dotnet test tests\OgmaLibrary.Tests\OgmaLibrary.Tests.csproj --configuration Release --no-restore --filter FullyQualifiedName~PasswordProviderTests` | Passed: 5 password-provider security/handoff tests |
| `dotnet test tests\OgmaLibrary.Tests\OgmaLibrary.Tests.csproj --configuration Release --no-restore --filter "FullyQualifiedName~PasswordProviderTests\|FullyQualifiedName~ReaderSessionServiceTests\|FullyQualifiedName~PdfiumAdapterPasswordTests"` | Passed: 16 password/session/PDFium handoff tests |
| `dotnet test tests\OgmaLibrary.Tests\OgmaLibrary.Tests.csproj --configuration Release --no-restore --filter FullyQualifiedName~PdfiumAdapterPasswordTests` | Passed: 1 real PDFium password-protected render test |
| `dotnet test tests\OgmaLibrary.Tests\OgmaLibrary.Tests.csproj --configuration Release --no-restore --filter "FullyQualifiedName~PasswordProviderTests\|FullyQualifiedName~BookDetail_ForgetPassword" --logger "console;verbosity=detailed"` | Passed: 7 password provider, non-macOS Keychain fail-closed, no-catalogue-secret, buffer-clearing, and book-detail forget-password tests |
| `dotnet test tests\OgmaLibrary.Tests.Ui\OgmaLibrary.Tests.Ui.csproj --configuration Release --no-restore --filter FullyQualifiedName~SkeletonRenderTests` | Passed: 5 UI skeleton tests after adding the book-detail protected-PDF action |
| `dotnet test tests\OgmaLibrary.Tests\OgmaLibrary.Tests.csproj --configuration Release --no-restore --filter FullyQualifiedName~RateLimitedHttpClientTests` | Passed: 3 provider rate-limit/retry tests |
| `dotnet test tests\OgmaLibrary.Tests\OgmaLibrary.Tests.csproj --configuration Release --no-restore --filter "FullyQualifiedName~HealthDashboardTests\|FullyQualifiedName~RateLimitedHttpClientTests"` | Passed: 10 health/batch/rate-limit tests |
| `dotnet test tests\OgmaLibrary.Tests\OgmaLibrary.Tests.csproj --configuration Release --no-restore --filter FullyQualifiedName~HealthDashboardTests --logger "console;verbosity=detailed"` | Passed: 9 health-dashboard tests including batch pause/resume, failed CSV export, chunk grouping, and 2,000-book retry simulation |
| `dotnet test tests\OgmaLibrary.Tests\OgmaLibrary.Tests.csproj --configuration Release --no-restore --filter FullyQualifiedName~Phase15SmartShelfPerformanceTests --logger "console;verbosity=detailed"` | Passed: 3 smart-shelf index/query-plan/2,000-book benchmark tests |
| `dotnet test tests\OgmaLibrary.Tests\OgmaLibrary.Tests.csproj --configuration Release --no-restore --filter "FullyQualifiedName~OcrJobProcessorTests\|FullyQualifiedName~OcrWorkerTests"` | Passed: 3 OCR processor/worker tests after internal extension-point hardening |
| `dotnet test tests\OgmaLibrary.Tests\OgmaLibrary.Tests.csproj --configuration Release --no-restore --filter "FullyQualifiedName~OcrJobProcessorTests\|FullyQualifiedName~OcrGoldenCorpusTests" --logger "console;verbosity=detailed"` | Passed: 4 OCR searchability, recovery, FTS/embedding handoff, and 1,000-page synthetic memory-profile tests |
| `dotnet test tests\OgmaLibrary.Tests.Architecture\OgmaLibrary.Tests.Architecture.csproj --configuration Release --no-restore --filter FullyQualifiedName~OcrExtensionPoint_IsInternal_In_Phase15` | Passed: 1 OCR extension-point visibility test |
| `dotnet test tests\OgmaLibrary.Tests\OgmaLibrary.Tests.csproj --configuration Release --no-restore --filter FullyQualifiedName~IndexManagerServiceTests` | Passed: 5 Index Manager tests including OCR pause/cancel/retry state transitions |
| `dotnet test tests\OgmaLibrary.Tests.Ui\OgmaLibrary.Tests.Ui.csproj --configuration Release --no-restore --filter FullyQualifiedName~SearchViewModelTests` | Passed: 9 search/index-manager UI tests including OCR job actions |
| `dotnet test tests\OgmaLibrary.Tests\OgmaLibrary.Tests.csproj --configuration Release --no-restore --filter "FullyQualifiedName~OcrJobQueueServiceTests\|FullyQualifiedName~BookDetail_RunOcr" --logger "console;verbosity=detailed"` | Passed: 7 OCR queue trigger/idempotency/security and book-detail status tests |
| `dotnet test tests\OgmaLibrary.Tests.Ui\OgmaLibrary.Tests.Ui.csproj --configuration Release --no-restore --filter FullyQualifiedName~SkeletonRenderTests` | Passed: 5 UI skeleton tests after adding the third book-detail action |
| `dotnet format OgmaLibrary.sln --verify-no-changes --no-restore` | Passed |
| `dotnet build OgmaLibrary.sln --configuration Release --no-restore` | Passed: 0 warnings, 0 errors |
| `dotnet test OgmaLibrary.sln --configuration Release --no-restore --logger "console;verbosity=minimal"` | Passed: 422 core tests, 24 architecture tests, 111 UI tests |
| `Test-Path src\OgmaLibrary.Infrastructure\bin\Release\net10.0\tessdata\eng.traineddata` | Passed: English tessdata copied to Release output |

## Implemented Locally

| Area | Evidence |
| --- | --- |
| Books OCR/password flags | `BookRow` and `BookConfiguration` map `IsOcrDerived` and `IsPasswordProtected` |
| Extracted-page source | `ExtractedPageRow` and `ExtractedPageConfiguration` map `Source` with default `"Extraction"` |
| Source-aware indexing | `IX_ExtractedPages_BookId_Source_PageNumber` allows OCR and direct extraction to coexist per page |
| Migration reversibility | `Phase15OcrPowerReaderSchema.Down()` drops new columns/indexes and restores the prior page-number unique index |
| Repository compatibility | `ExtractedPageRecord.Source` defaults to `"Extraction"` so Phase 10 callers remain source-compatible |
| OCR provider seam | `IOcrProvider` defines the native OCR boundary without coupling tests to Tesseract binaries |
| OCR job payload | `OcrJobPayload` records file path, language, total pages, and processed pages in the existing Jobs payload |
| OCR job processor | `OcrJobProcessor` renders pages through `IPdfRenderer`, calls `IOcrProvider`, writes source-tagged OCR pages, and resumes interrupted jobs by skipping persisted OCR pages |
| OCR searchability handoff | Completed OCR jobs replace page search chunks from OCR-derived `ExtractedPages`, so FTS5 can find scanned-book words immediately |
| FTS/embedding handoff | Completed OCR jobs enqueue `FtsReindexJob` and `EmbeddingJob` idempotently for the affected book |
| OCR golden corpus | `tests/golden-corpus/ocr-pipeline/` pins the `scanned-image-only` oracle and manifest for `OcrJob_ScannedPdf_BecomesSearchable` |
| Native OCR adapter | `TesseractOcrProvider` wraps the local Tesseract engine behind `IOcrProvider` |
| English OCR data | `Tesseract.Data.English` supplies `tessdata/eng.traineddata` without committing the binary to git |
| Hosted OCR worker | `OcrWorker` polls `IOcrJobProcessor` as a hosted service and backs off on idle/error states |
| OCR status surface | `IndexManagerService` projects recent `OcrJob` progress from the Jobs table; `IndexManagerViewModel` localizes active job count, state, and page progress |
| OCR job controls | `IIndexManagerService` exposes pause/cancel/retry for OCR jobs; `IndexManagerPanelView` surfaces per-job controls with localized labels |
| Book-detail OCR trigger | `BookDetailViewModel` and `BookDetailView` expose localized Run OCR queueing with success/already-queued/error feedback |
| OCR queue service | `OcrJobQueueService` creates or resumes `OcrJob` rows idempotently and validates the resolved source PDF path under the configured library root |
| Split-view scaffold | `SplitViewViewModel`, `SplitViewView`, and `MainShellViewModel.OpenSplitViewScaffold()` provide the Phase 15 V2 route with localized placeholder copy |
| Password provider boundary | `IPasswordProvider`, `PasswordRequest`, and disposable `PasswordResult` define the no-catalogue-secret unlock contract |
| Windows credential provider | `WindowsPasswordProvider` checks Windows Credential Manager and uses the OS credential prompt for missing passwords |
| macOS credential provider | `MacOsKeychainPasswordProvider` reads/deletes stored PDF passwords through macOS Keychain and fails closed off macOS |
| Password unlock view model | `PasswordUnlockViewModel` requests passwords without writing secret values to EF rows or sidecars |
| Book-detail forget password | `BookDetailViewModel` and `BookDetailView` expose a protected-PDF forget action that calls `IPasswordProvider.ForgetPasswordAsync` using the book content hash |
| Protected reader handoff | `IReaderSessionService.OpenProtectedAsync` and `IPdfRendererFactory.Open(filePath, password)` carry OS-supplied passwords to the renderer boundary |
| PDFium password render path | `PdfiumAdapter` detects required passwords, opens protected PDFs with supplied credentials, and clears its session password buffer on dispose |
| Provider HTTP resilience | `RateLimitedHttpClientHandler` spaces Google Books/Open Library requests and retries 429/503 responses with bounded exponential backoff |
| Batch chunk recovery metadata | `BatchEnrichmentOrchestrator` writes `BatchEnrichmentJobPayload` with 50-book chunk indexes so large runs resume from remaining per-book jobs |
| Batch operator controls | `ILibraryHealthService` exposes batch summaries, pause, resume, and failed-job CSV export for Health Dashboard wiring |
| Batch 2,000-book evidence | `BatchEnrichment_2000Books_CompletesWithRetry` creates 2,000 chunked jobs, simulates every-fifth provider retry, resumes failed jobs, and verifies completion |
| Smart-shelf composite indexes | `Phase15SmartShelfIndexes` adds `IX_Books_Status_Year`, `IX_ShelfBooks_ShelfId_BookId`, and `IX_BookMetadataFields_FieldName_Value` |
| Smart-shelf query evidence | `docs/benchmarks/phase-15/query-plans.md` records `EXPLAIN QUERY PLAN` output for five common smart-shelf filters |
| Smart-shelf baseline | `docs/benchmarks/phase-15/smart-shelf-baseline.json` records the 2,000-book P95 timing baseline |
| Smart-shelf stats panel | Index Manager shows representative smart-shelf query time and missing-index health |
| OCR extension point | `IOcrProvider` is internal, `[ExtensionPoint]`-marked, and only visible to friend assemblies until the Phase 23 SDK review |
| OCR ADR | `docs/adrs/0011-local-tesseract-ocr.md` records the local Tesseract decision and packaging consequences |

## Deferred / External Phase 15 Evidence

- Native Tesseract image-OCR golden-corpus run remains to be added when binary image fixtures are available; deterministic golden-corpus pipeline coverage is now in place.
- The Health Dashboard has backend contracts for OCR/batch operator controls; visual batch-control wiring can be done when the Health Dashboard UI is expanded.
- Real macOS Keychain CI evidence remains platform-dependent; the provider is wired and fails closed off macOS.
- Password golden-corpus is covered by the generated known-password PDFium fixture and no-catalogue-secret tests; a committed binary protected PDF fixture can be added once fixture licensing/storage policy is finalized.
- WP5 split-view scaffold is complete; V2 implementation remains out of Phase 15 scope.
- Full remote CI evidence will be recorded after pushing this phase.
