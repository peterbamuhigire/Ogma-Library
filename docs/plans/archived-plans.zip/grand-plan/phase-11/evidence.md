# Phase 11 Verification Evidence

Last updated: 2026-06-01

This file tracks implementation evidence for Phase 11 Semantic Search &
Embeddings.

## Current Position

Phase 11 WP1, WP2 backend foundations, WP3 semantic-search foundations, the
WP4 hybrid ranking formula, WP5 match-location backend/UI, WP6 erasure/spike
foundations, and WP7 UI/i18n foundations have started locally. The embedding schema has been aligned with the Phase 11 model/version requirements,
`Books.EmbeddingStatus` is in the EF model, a Phase 12-compatible `IAiProvider`
stub exists in Application, the local Ollama embedding provider is registered
behind Application contracts, and the embedding generation pipeline can process
pending chunks idempotently.

The implementation deliberately keeps embeddings as a rebuildable local index:
SQLite remains the source of truth, and vectors are stored as little-endian
float BLOBs keyed back to `SearchChunks`.

## Automated Verification

| Command | Result |
| --- | --- |
| `dotnet test tests\OgmaLibrary.Tests\OgmaLibrary.Tests.csproj --configuration Release --no-restore --filter FullyQualifiedName~Phase11EmbeddingSchemaTests` | Passed: 4 Phase 11 schema, repository, and Ollama adapter tests |
| `dotnet test tests\OgmaLibrary.Tests\OgmaLibrary.Tests.csproj --configuration Release --no-restore --filter "FullyQualifiedName~EmbeddingGenerationServiceTests\|FullyQualifiedName~EmbeddingGenerationWorkerTests"` | Passed: 4 embedding generation service and worker tests |
| `dotnet test tests\OgmaLibrary.Tests\OgmaLibrary.Tests.csproj --configuration Release --no-restore --filter FullyQualifiedName~CosineSimilarityServiceTests` | Passed: 6 cosine arithmetic, zero-vector, SIMD-width, and deterministic top-K tests |
| `dotnet test tests\OgmaLibrary.Tests\OgmaLibrary.Tests.csproj --configuration Release --no-restore --filter FullyQualifiedName~SemanticSearchServiceTests` | Passed: 4 semantic search, exact-fallback, exact+semantic merge, and 2,000-book P95 benchmark tests |
| `dotnet test tests\OgmaLibrary.Tests\OgmaLibrary.Tests.csproj --configuration Release --no-restore --filter FullyQualifiedName~HybridRankingServiceTests` | Passed: 7 hybrid ranking formula, fallback, tie-break, and 100-query determinism tests |
| `dotnet test tests\OgmaLibrary.Tests\OgmaLibrary.Tests.csproj --configuration Release --no-restore --filter FullyQualifiedName~MatchLocationServiceTests` | Passed: 10 match-location, confidence-label, and enrichment tests |
| `dotnet test tests\OgmaLibrary.Tests\OgmaLibrary.Tests.csproj --configuration Release --no-restore --filter FullyQualifiedName~EmbeddingErasureTests` | Passed: 2 embedding erasure, audit-event, status-reset, and requeue-oracle tests |
| `dotnet test tests\OgmaLibrary.Tests.Ui\OgmaLibrary.Tests.Ui.csproj --configuration Release --no-restore --filter FullyQualifiedName~SearchViewModelTests` | Passed: 8 search/index UI tests, including semantic match-location/confidence metadata, degraded exact-fallback indicator, and embedding-erasure confirmation countdown |
| `dotnet test tests\OgmaLibrary.Tests.Architecture\OgmaLibrary.Tests.Architecture.csproj --configuration Release --no-restore` | Passed: 18 architecture tests |
| `dotnet build OgmaLibrary.sln --configuration Release --no-restore` | Passed: 0 warnings, 0 errors |
| `dotnet test OgmaLibrary.sln --configuration Release --no-restore` | Passed: Architecture 18, Core 300, UI 104 |
| Document review: `docs/spikes/ANN-SQLite-Vec-Spike.md`, `docs/architecture/adr/ADR-0006-hybrid-search.md` | Added sqlite-vec/Vec1 spike plan, `IVectorIndex` proposed contract, ANN trigger thresholds, fallback criteria, and ADR-0006 ANN stub |
| Closeout evidence | `docs/qa/evidence/phase11-closeout-20260601.md` records local implementation scope, verification, and remaining non-local gates |
| Remote CI evidence attempt | `docs/qa/evidence/phase11-remote-ci-20260601.md` records that `gh` is unavailable locally and the unauthenticated GitHub Actions API returned 404; authenticated Actions evidence remains pending |

## Evidence Map

| Area | Evidence |
| --- | --- |
| AI provider gateway stub | `IAiProvider` under `src/OgmaLibrary.Application/Ai/` |
| Ollama embedding contract | `IOllamaEmbeddingProvider` and `OllamaEmbeddingResult` under `src/OgmaLibrary.Application/Search/` |
| Local-only Ollama adapter | `OllamaEmbeddingAdapter` under `src/OgmaLibrary.Infrastructure/AI/Ollama/`; tests assert loopback `/api/embeddings` use and unavailable-service degradation |
| Embedding schema | `20260601104115_Phase11EmbeddingSchema` adds `Books.EmbeddingStatus`, `EmbeddingVectors.ModelName`, `ModelVersion`, `GeneratedAtUtc`, non-null vector BLOBs, and unique `(ChunkId, ModelName, ModelVersion)` index |
| Vector repository | `IEmbeddingVectorRepository` and `EmbeddingVectorRepository` round-trip float arrays through SQLite BLOBs and support per-book reads plus full erasure |
| Embedding generation pipeline | `IEmbeddingGenerationService`, `ISemanticSearchReadModel`, `EmbeddingGenerationService`, and `EmbeddingGenerationWorker`; tests cover idempotency, unavailable Ollama degradation, failure jobs, progress events, and worker polling |
| Cosine similarity | `CosineSimilarityService` computes SIMD-backed cosine scores with deterministic top-K ordering |
| Semantic search service | `ISemanticSearchService` and `SemanticSearchService` embed the query locally, brute-force score stored vectors, merge exact + semantic results through hybrid ranking, enrich locations/confidence, and fall back to exact Phase 10 search when Ollama or embeddings are unavailable |
| Hybrid ranking formula | `IHybridRankingService` and `HybridRankingService` blend exact, semantic, recency, status, and rating signals with deterministic score/`BookId` ordering and no-embedding fallback |
| Match-location backend | `MatchLocation`, `ConfidenceLabel`, `IMatchLocationService`, and `MatchLocationService` derive ordered explanation badges and confidence labels from exact, FTS, semantic, and hybrid ranking signals |
| Search panel semantic metadata | `SearchViewModel` consumes `ISemanticSearchService`; result rows expose confidence and match-location metadata for the search panel |
| Search panel badges/i18n/icons | `SearchPanelView` renders localized semantic availability, localized confidence labels, focusable match-location badges with automation names/tooltips, and existing catalog icons as placeholders until premium Phase 11 assets arrive |
| Embedding erasure backend | `IEmbeddingErasureService` and `EmbeddingErasureService` delete vectors, reset book embedding status, and write an `EmbeddingVectorsErased` audit event in one transaction |
| Embedding erasure UI | `IndexManagerViewModel` and `IndexManagerPanelView` expose an "Erase embeddings" flow with a two-step confirmation, countdown gate, localized copy, progress state, and service-call test |
| ANN spike/ADR | `docs/spikes/ANN-SQLite-Vec-Spike.md` and `docs/architecture/adr/ADR-0006-hybrid-search.md` document the sqlite-vec evaluation path and brute-force trigger thresholds |
| Architecture guard | Architecture tests verify Application semantic search does not depend on Infrastructure AI and the Ollama adapter remains an internal Infrastructure detail |

## Remaining Phase 11 Work

- WP2: backend generation service and worker are implemented locally; remaining work is broader batching/rate-limit tuning, model-change configuration, and UI surfacing of unavailable-Ollama events.
- WP3: cosine similarity, deterministic top-K, semantic search service, and local 2,000-book P95 benchmark are implemented locally.
- WP4: hybrid ranking formula, defaults, determinism, and graceful no-embedding fallback are implemented locally; persistence-backed weight settings remain.
- WP5: backend match-location derivation, confidence labels, and search-panel metadata display are implemented locally; fuller badge styling, keyboard/SR behavior, and i18n remain.
- WP6: embedding erasure service with audit event, Index Manager confirmation countdown, and ANN spike/ADR docs are implemented locally; broader privacy-center placement remains for Phase 12.
- WP7/WP8: premium icon replacement, manual screen-reader/accessibility checks, full regression evidence, and remote CI evidence.
